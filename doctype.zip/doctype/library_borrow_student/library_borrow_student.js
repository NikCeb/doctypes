// Copyright (c) 2022, Frappe Technologies Pvt. Ltd. and contributors
// For license information, please see license.txt


/*frappe.ui.form.on("Library Borrow Student","onload",function(frm){
    frm.set_df_property('lb_teacher', 'hidden', 1);
    msgprint("hi");
});




frappe.ui.form.on("Library Borrow Student", {
  refresh: function(frm) {
    if(frm.doc.lb_position != "Student") {
		    frm.set_df_property("lb_teacher", "hidden", 1);
    }
    else{
        frm.set_df_property("lb_teacher", "reqd", 1); // Remove Student input
        frm.set_df_property("lb_student", "reqd", 0);
        frm.set_df_property("lb_student", "hidden", 1);
    }
  }
});
*/
